(function($) {
    "use strict";

    jQuery(document).ready(function($) {
   $(".case-studies-carousel").owlCarousel({
            margin: 30,
            dots: false,
            loop: true,
            nav: false,
            autoplay: false,
            autoplayTimeout: 3000,
            responsive: {
                0: {
                    items: 1,
                },
                768: {
                    items: 2,
                },
                992: {
                    items: 4
                }
            }
        });

}(jQuery));
   // var uluru = {lat: -25.363, lng: 131.044};
   //  $('.map')
   //    .gmap3({
   //      zoom: 4,
   //      center: uluru
   //    })
   //    .marker({
   //      position: uluru
   //    })
   //    .infowindow({
   //      content: "Hello from Uluru"
   //    })
   //    .then(function (infowindow) {
   //      var map = this.get(0);
   //      var marker = this.get(1);
   //      marker.addListener('click', function() {
   //        infowindow.open(map, marker);
   //      });
   //    });
